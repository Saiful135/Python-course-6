list1 = list(map(int, input("Enter elements of first list (space-separated): ").split()))
list2 = list(map(int, input("Enter elements of second list (space-separated): ").split()))

set1, set2 = set(list1), set(list2)
print("Union:", list(set1 | set2))
print("Intersection:", list(set1 & set2))
print("Symmetric Difference:", list(set1 ^ set2))
