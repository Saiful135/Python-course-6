variable = input("Enter a num: ")
try:
    eval_variable = eval(variable)
    print("Data type:", type(eval_variable).__name__)
except:
    print("Data type: string")
