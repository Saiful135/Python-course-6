A= eval(input("Input:"))

B = type(A)
print(B)