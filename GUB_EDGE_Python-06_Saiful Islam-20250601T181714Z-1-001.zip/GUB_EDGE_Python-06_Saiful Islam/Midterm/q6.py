import random
a = random.randint( 1, 100)
time = 4
print("guess ")
for attempt in range (1,time+1):
    guess = int(input(f"attempt{attempt}:enter: "))
    if guess ==a:
        print("guess correct")
        break
    elif guess<a:
        print("too low!")
    else:
        print ("too high")
else:
    print(f"sorry,the number was {a}")