user_input= input("enter string:")

reversed_string = user_input[::-1]

print(reversed_string)
